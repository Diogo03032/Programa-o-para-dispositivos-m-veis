import React, { useState } from 'react';
import { TextInput, Button, Alert, SafeAreaView, Text, StyleSheet } from 'react-native';

export default function App() {
  const [nome, setNome] = useState('');
  const handlePress = () => {
    Alert.alert("Valor digitado", nome);
  };

  return (
    <SafeAreaView style={styles.container}>
      <Text> Digite seu nome aqui:</Text>
      <TextInput 
        style={styles.input}
        placeHolder="Seu nome aqui"
        value = {nome} 
        onChangeText = {setNome}
      />
      <Button
        title= 'Clique aqui'
        onPress =  {handlePress}
      /> 
    </SafeAreaView>  
  );
}

const styles = StyleSheet.create({
  container: { padding: 50},
    input: {
      borderColor: '#aaa',
      borderWidth: 1,
      marginvertical: 100,
      paddingHorizontal: 0,
    },
  
});