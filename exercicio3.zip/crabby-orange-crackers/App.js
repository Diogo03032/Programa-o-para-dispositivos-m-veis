import React, {   useState } from 'react';
import { StyleSheet, Text, SafeAreaView, TextInput, Button, ScrollView } from 'react-native';

export default function App() {

  const [itens, setItens] = useState([]);
  const [texto, setTexto] = useState('');

  const adicionarItem = () => {
    if (texto.trim() === '') return; 
    setItens([...itens, texto]);
    setTexto(''); 
  };

  return (
    <SafeAreaView style={styles.container}>
      
      <Text style={styles.cabecalho}>
        Lista de compras
      </Text>
      
      <TextInput
        style={styles.input}
        placeholder="Digite um item"
        value={texto}
        onChangeText={setTexto}
      />

      <Button 
        title="Adicionar" 
        onPress={adicionarItem}
      />

      <ScrollView style={styles.lista}>
        {itens.map((item, index) => (
          <Text key={index} style={styles.item}>
            {item}
          </Text>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    marginTop: 50
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 10,
    marginBottom: 10
  },
  cabecalho: {
    paddingVertical: 10,
    paddingHorizontal: 1
  },
  lista: {
    marginTop: 20
  },
  item: {
    fontSize: 18,
    marginBottom: 10
  }
});



