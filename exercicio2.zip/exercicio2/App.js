import { StyleSheet, Text, View, ScrollView, Image } from 'react-native';
import  React from 'react';

const img1 = require('./assets/img1.jpg');
const img2 = require('./assets/img2.jpg');
const img3 = require('./assets/img3.webp');
const img4 = require('./assets/img4.webp');
const img5 = require('./assets/img5.png');
const img6 = require('./assets/img6.avif');

export default function App() {
  
  
  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>
        Filmes
      </Text>
      <ScrollView style={styles.scroll}>
        
        <Image source = {img1}  style = {styles.remoteImg}
        />

        <Image source = {img2}  style = {styles.remoteImg}
        />

        <Image source = {img3}  style = {styles.remoteImg}
        />

        <Image source = {img4}  style = {styles.remoteImg}
        />

        <Image source = {img5}  style = {styles.remoteImg}
        />

        <Image source = {img6}  style = {styles.remoteImg}
        />

      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 50,
    alignItens: 'center'
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  remoteImg: {
    width: 350, 
    height: 500,
    margin: 15

  }
});
